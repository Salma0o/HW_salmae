from setuptools import setup

setup(name='AppTests', version=1.0, description='Honey comb App tests',
      author='Salma Eyadi', author_email='salmaay96@gmail.com',
      packages=['AppTests'])

